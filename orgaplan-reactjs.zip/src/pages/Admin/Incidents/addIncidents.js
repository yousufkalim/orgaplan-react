import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";
import GLOBALS from "../../../globals";
import Form from "../../../components/Form";
import Button from "../../../components/Button";
import Heading from "../../../components/Heading";
import FormInput from "../../../components/FormInput";
import SmallText from "../../../components/SmallText";
import FormLabel from "../../../components/FormLabel";
import FormSelect from "../../../components/FormSelect";
import FormMultipleUpload from "../../../components/FormMultipleUpload";
import { ReactComponent as BackArrow } from "../../../assets/icons/BackArrow.svg";
import { TimePicker } from "antd";

const useStyles = makeStyles(() => ({
  root: {
    padding: GLOBALS.Styles.pagePadding,
  },
  content: {
    padding: GLOBALS.Styles.pageContentPadding,
    marginTop: GLOBALS.Styles.pageContentMargin,
  },
   error: {
    color: "red",
  },
}));




export default function AddIncidents(props) {
  const classes = useStyles();
  const store = useSelector((state) => state.auth);
  const adminStore = useSelector((state) => state.admin);
  const [name, setName] = useState("");
  const [dropdownCompanies, setDropdownCompanies] = useState([]);
  const [dropdownLocation, setDropdownLocation] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState([]);
  const [location, setLocations] = useState([]);
  const [selectedLocationType, setselectedLocationType] = useState("");
  const [companyId, setCompanyId] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [isBillable, seIsBillable] = useState(false);
  const [price, setPrice] = useState("");
  const [type, setType] = useState("");

  const [comment, setComment] = useState("");
  const [image, setImage] = useState([]);
  const [selctedLocationObject, setselctedLocationObject] = useState("");
  const [nameError, setNameError] = useState(""); //working
  const [comapnyError, setComapnyError] = useState("");
  const [dateError, setDateError] = useState("");
  const [timeError, setTimeError] = useState("");

    useEffect(() => {
    fetchData();
    // eslint-disable-next-line
  }, []);
   useEffect(() => {
    fetchLocationDataOnTypeChange();
    // eslint-disable-next-line
  }, [selectedLocationType]);

   const fetchData = async () => {
   const response = await GLOBALS.API({
        uri: `${GLOBALS.Constants.GET_SITE_INCIDENT}/${adminStore.site.siteId._id}`,
        token: store.token,
       });
      
     console.log('response', response)
    
    if(response.success) {
      if(response.data.site_companies) {
        const temp = [];
          response.data.site_companies.map((item, index) => {
            return temp.push({ label: item.companyId.name, value: item.companyId._id });
          });
          setDropdownCompanies(temp);
      }
        if (response.data.locationTypes) {
          setLocations(response.data.locationTypes);
          // setDropdownLocationType(temp);
        }

    }
 }



  const onFormSubmit = async () => {
  // const notificationTo = values.notificationTo.map((item) => item.label);

  var formdata = new FormData();
  // formdata.append("photos", values.logo[0].file);
  formdata.append("name", name);
  formdata.append("date", date);
  formdata.append("time", time);
  formdata.append("type", type);
  formdata.append("description", description);
  formdata.append("isBillable", isBillable);
  formdata.append("price", price);
  formdata.append("comment", comment);
  // formdata.append("location", JSON.stringify({"deliveryArea":"600952a9df49e51b42fab57b"}));
  // formdata.append("type", );
  formdata.append("companyId", companyId);
  formdata.append("siteId", adminStore.site.siteId._id);
    console.log(store.token)
     await GLOBALS.API({
      method: "POST",
      uri: GLOBALS.Constants.POST_ADD_SITE_INCIDENTS,
     headers: {
          Authorization: store.token,
        },
      body: formdata,
    });

    props.history.push("/incidents");
  };
   const nameChange = (e) => {
     if (e.target.name === "name") {
       setName(e.target.value);
       if (e.target.value === "" || e.target.value === null) {
         setNameError(true);
       } else {
         setNameError(false);
       }
     }
     if (e.target.name === "comapnyId") {
       setCompanyId(e.target.value);
       if (e.target.value === "" || e.target.value === null) {
         setComapnyError(true);
       } else {
         setComapnyError(false);
       }
     }
     if (e.target.name === "date") {
       setDate(e.target.value);
       // console.log(date)
       if (e.target.value === "" || e.target.value === null) {
         setDateError(true);
       } else {
         setDateError(false);
       }
     }
     if (e.target.name === "time") {
       setTime(e.target.value);
       if (e.target.value === "" || e.target.value === null) {
         setTimeError(true);
       } else {
         setTimeError(false);
       }
     }
     if (e.target.name === "location") {
       // setTime(e.target.value);
       const selectedObject = dropdownLocation.filter(
         (x) => x.value === e.target.value,
       );

       setSelectedLocation(selectedObject[0]);
       const locationObject = {};
       locationObject[0] = selectedLocationType;

       locationObject[1] = e.target.value;
       setselctedLocationObject(locationObject);

       if (e.target.value === "" || e.target.value === null) {
         setTimeError(true);
       } else {
         setTimeError(false);
       }
     }
     if (e.target.name === "description") {
       setDescription(e.target.value);
 
     }
     if (e.target.name === "seIsBillable") {
       seIsBillable(e.target.value);

     }
     if (e.target.name === "price") {
       setPrice(e.target.value);

     }
     if (e.target.name === "comment") {
       setComment(e.target.value);
     }
     if (e.target.name === "profile") {
       setImage(e.target.value);
     }
     if (e.target.name === "type") {
       setType(e.target.value);
     }
   };
  function handleChange(name, value) {
    if (name === "image") setImage(value);
  }

  const fetchLocationDataOnTypeChange = async () => {
    if(selectedLocationType === 'STORAGEAREA') {
        const response = await GLOBALS.API({
        uri: `${GLOBALS.Constants.GET_STORAGE_AREA_BY_SITE_ID}/${adminStore.site.siteId._id}`,
        token: store.token,
      });
      if(response.success) {
            if (response.data) {
              const storageValue =[{
                label: response.data.name,
                value: response.data._id,
              }
            ];
              // temp = storageValue;
              // response.data.map((item, index) => {
              //   return temp.push({ label: item.name, value: item._id });
              // });
              setDropdownLocation(storageValue);
            }
      }
    }
    if(selectedLocationType === 'DELIVERYAREA') {
        const response = await GLOBALS.API({
        uri: `${GLOBALS.Constants.GET_DELIVERY_AREA_BY_SITE_ID}/${adminStore.site.siteId._id}`,
        token: store.token,
      });
      if(response.success) {
        if(response.data) {
       const temp = [];
          response.data.map((item, index) => {
            return temp.push({ label: item.name, value: item._id });
          });
          setDropdownLocation(temp);
        }
      
      }
      console.log(response);
    }
  }
  const locationTypeChange = (e)=> {
     setselectedLocationType(e.target.value);
  }
  const timeChange = (e) => {
    setTime(e?._d)
    console.log(e)
  }
  const submitHandler = (e) => {
    e.preventDefault();
    if (name === "" || name === null) {
      setNameError(true);
    }
    // if (types === "" || types === null) {
    //   setTypeError(true);
    // }
    // if (color === "" || color === null) {
    //   setColorError(true);
    // }
    // if (startDate === "" || startDate === undefined || startDate === null) {
    //   setStartDateError(true);
    //   setIsDateSelect(true);
      
    // } 
    // if (endDate === "" || endDate === undefined || endDate === null) {
    //   setEndDateError(true);
    // } 
    // if( rate === "" || rate === null){
    //   setRateError(true);
    // }
    // if( name !== "" && types !== "" && color !== "" && startDate !== "" && endDate !== ""){
    //   clearFileds();
    // }
    else {
      // clearFileds();
      // submitIncident()
    }
          onFormSubmit();

  };


   return (
     <div className={classes.root}>
       <IconButton onClick={() => props.history.goBack()}>
         <BackArrow style={{ width: 30, height: 30 }} />
       </IconButton>
       <Heading primary="CREATE AN INCIDENTS" />
       <div className={classes.content}>
         <Form.Form onSubmit={submitHandler}>
           <Form.Row>
             <FormLabel bold primary="DESIGNATION* :" />
             <FormInput
               name="name"
               style={GLOBALS.Styles.inputWidth}
               placeholder="Name of incident"
               onChange={nameChange}
               value={name}
             />
           </Form.Row>
           <Form.Row>
             <FormLabel bold primary="NAME OF COMPANY* :" />
             <Form.Row noMargin width="48%">
               <FormSelect
                 placeholder="Nom de I'enterprise"
                 name="comapnyId"
                 style={GLOBALS.Styles.inputWidth}
                 onChange={nameChange}
                 values={dropdownCompanies}
               />
               <span
                 style={{
                   textAlign: "center",
                   marginRight: "50px",
                   marginTop: "10px",
                 }}
               >
                 General Contractor name
               </span>
             </Form.Row>
           </Form.Row>

           <Form.Row>
             <FormLabel bold primary="DATE AND TIME* : " />
             <Form.Row noMargin width="48%">
               <FormInput
                 type="date"
                 style={GLOBALS.Styles.inputWidth}
                 placeholder="Date"
                 name="date"
                 onChange={nameChange}
                 value={date}
               />
               <TimePicker
                 name="time"
                 style={{ width: "48%", height: "45px", color: "#8B8989" }}
                 onChange={timeChange}
                 //  value={time}
               />
             </Form.Row>
           </Form.Row>
           <Form.Row>
             <FormLabel bold primary="LOCATION : " />
             <Form.Row noMargin width="48%">
               <FormSelect
                 placeholder="Type of location"
                 name="locationType"
                 style={GLOBALS.Styles.inputWidth}
                 onChange={locationTypeChange}
                 values={[
                   { value: "STORAGEAREA", label: "Storage Area" },
                   { value: "DELIVERYAREA", label: "Delivery Area" },
                 ]}
               />
               <FormSelect
                 placeholder="LOCATION"
                 name="location"
                 style={GLOBALS.Styles.inputWidth}
                 onChange={nameChange}
                 values={dropdownLocation}
                 disabled={!selectedLocationType}
               />
             </Form.Row>
           </Form.Row>
           <Form.Row>
             <FormLabel bold primary="GENERAL: " />
             <Form.Row width="48%">
               <FormSelect
                 name="type"
                 id="bill"
                 style={{ width: "40%", height: "45px", color: "#8B8989" }}
                 //  onChange={(e) => {
                 //    seIsBillable(e.target.value);
                 //    console.log("billable is", isBillable);
                 //    isBillable === "No" && console.log("value");
                 //  }}
                 onChange={nameChange}
                 value={type}
                 values={[
                   { value: "INCIDENT", label: "Incident" },
                   { value: "MEAN", label: "Mean" },
                   { value: "DELAY", label: "Delay" },
                   { value: "UNEXPRECTED", label: "Unexp" },
                 ]}
               />
             </Form.Row>
           </Form.Row>
           <Form.Row>
             <FormLabel bold primary="DESCRIPTION : " />
             <FormInput
               textArea
               rows={5}
               maxLength="300"
               style={GLOBALS.Styles.inputWidth}
               onChange={nameChange}
               placeholder="Information complementaires"
               name="description"
             />
           </Form.Row>
           <Form.Row>
             <FormLabel bold primary="ADD PICTURES : " />
             <Form.Row noMargin width="48%">
               <FormMultipleUpload
                 name="profile"
                 values={image}
                 style={GLOBALS.Styles.inputWidth}
                 onChange={(values) => {
                   handleChange("image", values);
                 }}
               />
             </Form.Row>
           </Form.Row>
           <Form.Row>
             <FormLabel bold primary="BILLABLE* : " />
             <Form.Row width="48%">
               <select
                 name="bill"
                 id="bill"
                 style={{ width: "40%", height: "45px", color: "#8B8989" }}
                 onChange={(e) => {
                   seIsBillable(e.target.value);
                   console.log("billable is", isBillable);
                 }}
               >
                 <option selected={true} value="true">
                   Yes
                 </option>
                 <option value="false">No</option>
               </select>
             </Form.Row>
           </Form.Row>
           <Form.Row>
             <FormLabel bold primary="AMOUNT :" />
             <Form.Row width="48%" noMargin alignItems="center">
               <Form.Row width="24%" noMargin alignItems="center">
                 <FormInput
                   type="number"
                   name="price"
                   onChange={nameChange}
                   disabled={isBillable == false}
                   // error={penaltyforLateDelivery}
                 />
                 {/*<div >@</div>*/}
                 <SmallText style={{ marginLeft: 10 }} primary="€" />
               </Form.Row>
             </Form.Row>
           </Form.Row>

           <Form.Row alignItems="flex-start">
             <FormLabel bold primary="COMMENT ON INVOICE : " />
             <FormInput
               textArea
               maxLength="300"
               rows={3}
               style={GLOBALS.Styles.inputWidth}
               onChange={nameChange}
               placeholder="Ajouter un commentaire"
               name="comment"
             />
           </Form.Row>
           <Form.ButtonContainer>
             <Button
               type="submit"
               minWidth={200}
               text="VALIDER"
               fullWidth={false}
               disabled={!name || !date || !dropdownCompanies || !isBillable}
             />
           </Form.ButtonContainer>
         </Form.Form>
       </div>
     </div>
   );
}
